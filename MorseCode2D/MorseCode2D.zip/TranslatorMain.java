package MorseCode2D;

import java.io.IOException;

public class TranslatorMain {

    public static void main(String[] args) throws IOException {
       MorsePanel GUI = new MorsePanel();
       GUI.setLocationRelativeTo(null);
    }
}