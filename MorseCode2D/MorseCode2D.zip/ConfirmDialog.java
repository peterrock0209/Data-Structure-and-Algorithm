package MorseCode2D;

import java.util.List;

import javax.swing.JOptionPane;

@SuppressWarnings("serial")
public class ConfirmDialog extends JOptionPane {

    public ConfirmDialog (String title, List <String> Message){

    }
}