package Hw6_18001166;

public interface Entry <K,E> {
	K getKey(); //K is key of element
	E getValue(); //E is value of element
}
